package com.company;
import java.util.Set;

public class Example {
    public void print(Set<String> strSet) { }
    public void print(Set<Integer> intSet) { }
}